
package edu.ics111.h01;

import java.util.Scanner;

/**
 * BONUS: Represents a simulation of rolling user inputed die. 
 * 
 * @author Zyan Neri
 *
 */
public class BonusUserDie {
  /**
   * BonusUserDie simulates rolling of one user determined die. Program then outputs results.
   * 
   * @param args not used.
   * 
   */
  public static void main(String[] args) {
    
    // Using Scanner to take user input to determine die sides!
    
    Scanner userBonusDie = new Scanner(System.in);
    System.out.println("Please enter valid die value: ");
    int input = userBonusDie.nextInt(); // .nextInt() Allows us to take integer user inputs
    userBonusDie.close(); // Close scanner for good practice!
    
    // I got If, Else logical structure from: ChatGPT
    // https://chatgpt.com/

    if (input <= 1) { // Rejecting 0 and below inputs
      System.out.println("Invalid input!");
      System.out.println();
    } else {
      
      // User-die computations

      int roll = (int) (Math.random() * input + 1); // Takes user input to determine die "sides"
      
      // Outputting results of our die roll! 
      
      System.out.println("BONUS: You rolled a " + roll);
      System.out.println();

    }

  }

}
