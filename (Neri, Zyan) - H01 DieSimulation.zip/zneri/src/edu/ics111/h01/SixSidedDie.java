
package edu.ics111.h01;

/**
 * Represents a simulation of rolling two six-sided dies.
 * 
 * @author Zyan Neri
 *
 */

public class SixSidedDie {
  /**
   * SixSidedDie simulates rolling of one user determined die. Program then outputs results.
   * 
   * @param args not used.
   * 
   */
  public static void main(String[] args) {
    // Declare variables: die1, die2, & twentyDie

    int die1; // Variable of 1st die roll
    int die2; // Variable of 2nd die roll

    // Computations for die1, die2, & twentyDie

    die1 = (int) (Math.random() * 6 + 1);
    die2 = (int) (Math.random() * 6 + 1);

    // Outputting the results of our die rolls!

    System.out.print("The first die comes up ");
    System.out.println(die1);
    System.out.print("The second die comes up ");
    System.out.println(die2);
    System.out.print("Your total roll is ");
    System.out.println(die1 + die2);

  }

}
