
package edu.ics111.h01;

/**
 * Represents a simulation of rolling one twenty-sided die. 
 * 
 * @author Zyan Neri
 *
 */
public class TwentySidedDie {
  /**
   * TwentySidedDie simulates rolling of one twenty-sided die. Program then outputs results.
   * 
   * @param args not used.
   * 
   */
  public static void main(String[] args) {

    // Variable for twenty-sided die
    
    int twentyDie;

    // Computation for twentyDie
    
    twentyDie = (int) ((Math.random() * 20) + 1);
    
    // Outputting the results of our die roll!

    System.out.print("Your roll for a TWENTY-sided die is ");
    System.out.println(twentyDie);

  }

}
