package edu.ics111.h03;

/**
 * Represents a simulation of rolling two six-sided dies.
 * 
 * @author Zyan Neri
 *
 */

public class DieProbability {

  /**
   * DieProbability simulates rolling of two dies.
   * Program will output how many individual rolls it takes to reach 7.
   * 
   * @param args not used.
   */
  public static void main(String[] args) {
    
    // Declaring variables necessary for die-roll operation, identical to H01 operation
    // except for the addition of the 'counter' integer variable which is necessary
    // to record how many die-rolls it takes to get to 7.
    
    int die1 = 0;
    int die2 = 0;
    int rollTotal = die1 + die2;
    int counter = 0;
    
    // Additionally, I have implemented a while loop, telling the program to execute 
    // the die-roll operation continuously until we get to the assignment's requirement 
    // of 7.

    while (rollTotal != 7) {
      counter++;
      die1 = (int) (Math.random() * 6 + 1);
      die2 = (int) (Math.random() * 6 + 1);
      rollTotal = die1 + die2;
    }
    
    // Once the rollTotal matches 7, the program "breaks out" of the loop and displays
    // how many intervals were taken to get to 7.

    System.out.println();
    System.out.print("It took ");
    System.out.print(counter);
    System.out.println(" rolls to get to total value of 7");
  }
}