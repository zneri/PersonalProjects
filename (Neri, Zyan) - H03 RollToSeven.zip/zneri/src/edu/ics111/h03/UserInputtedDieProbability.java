package edu.ics111.h03;

/**
 * Represents a simulation of rolling two six-sided dies.
 * 
 * @author Zyan Neri
 *
 */

public class UserInputtedDieProbability {  
  /**
   * UserInputtedDieProbability simulates rolling of two dies.
   * Program will output how many individual rolls it takes to reach user provided value.
   * 
   * @param args not used.
   */
  public static void main(String[] args) {
    
    // Creating variable for user's input, utilizing TextIO and denying entries by
    // using || (or) operator
    
    int userInput;

    System.out.print("Please enter a valid value between 2-12: ");
    userInput = TextIO.getlnInt();
    while (userInput < 2 || userInput > 12) {
      System.out.println("Invalid entry! Please re-enter a VALID entry between 2-12:");
      userInput = TextIO.getlnInt();
    }
    
    // Once user-entry passes our first while loop, it will enter the computation while loop
    // rolling die until they've reached the user-determined value
    
    int counter = 0;
    int die1 = 0;
    int die2 = 0;
    int rollTotal = 0;
    
    // Loop will continue rolling and recording the attempts until the rollTotal == userInput

    while (rollTotal != userInput) {
      counter++;
      die1 = (int) (Math.random() * 6 + 1);
      die2 = (int) (Math.random() * 6 + 1);
      rollTotal = die1 + die2;
    }
    
    // Once rollTotal makes the boolean-statement above FALSE, program will "break out" of
    // loop and display results.

    System.out.println();
    System.out.print("It took ");
    System.out.print(counter);
    System.out.println(" rolls to get to total value of " + userInput);
  }
}

