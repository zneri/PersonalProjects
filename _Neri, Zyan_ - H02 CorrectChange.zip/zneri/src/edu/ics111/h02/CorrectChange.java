
package edu.ics111.h02;

/**
 * A program aimed to help cashiers calculate the correct change.
 * 
 * @author Zyan Neri
 *
 */
public class CorrectChange {
  /**
   * CorrectChange takes a user-inputed item value and outputs amount of change leftover.
   * 
   * @param args not used.
   * 
   */
  public static void main(String[] args) {

    // Prompt user with TextIO, asking for price of item and amount paid. Storing values as doubles.

    double itemCost;
    System.out.print("How much does the item cost?");
    itemCost = TextIO.getlnDouble();

    double paidValue;
    System.out.print("How much was paid");
    paidValue = TextIO.getlnDouble();
    System.out.println();

    // Computations for change, variables are declared as needed to abide by Checkstyle standards.

    double resultDollars;
    double change;

    change = paidValue - itemCost;

    // Dollars computation.
    // Each iteration updates the 'change' variable by subtracting it by the results.

    resultDollars = Math.floor(change / 1.00);
    change = change - resultDollars * 1.00;

    // Quarters computation.

    double resultQuarters;
    resultQuarters = Math.floor(change / 0.25);
    change = change - resultQuarters * 0.25;

    // Dimes computation.

    double resultDimes;
    resultDimes = Math.floor(change / 0.10);
    change = change - resultDimes * 0.10;

    // Pennies computation.

    double resultPennies;
    resultPennies = change / 0.01;

    // Outputting results using format specifier to ensure output is in whole #s

    System.out.printf("The change is %1.0f dollars", resultDollars);
    System.out.printf(", %1.0f quarters", resultQuarters);
    System.out.printf(", %1.0f dimes", resultDimes);
    System.out.printf(", %1.0f pennies", resultPennies);

  }

}
